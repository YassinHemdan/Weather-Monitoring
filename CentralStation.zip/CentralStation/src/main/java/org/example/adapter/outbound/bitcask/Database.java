package org.example.adapter.outbound.bitcask;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


public class Database implements AutoCloseable{
    private final Path dbDir;
    private final SegmentsManager segmentsManager;
    private final Map<String, EntryLocation> keyDir = new ConcurrentHashMap<>();

    public Database(String dbPath) throws IOException {
        this.dbDir = Paths.get(dbPath);
        this.segmentsManager = new SegmentsManager(dbDir);
    }

    public synchronized void set(Entry entry) throws IOException, IllegalAccessException {
        byte[] data = serializeEntry(entry);
        EntryLocation location = this.segmentsManager.write(data);
        keyDir.put(entry.getKey(), location);
    }


    public Entry get(String key) throws IOException {
        EntryLocation location = keyDir.get(key);
        byte[] data = this.segmentsManager.read(
                location.offset(),
                location.fileId(),
                location.entrySize());

        ByteBuffer buffer = ByteBuffer.wrap(data);
        long timestamp = buffer.getLong();
        int keySize = buffer.getInt();
        int valueSize = buffer.getInt();

        byte[] keyBytes = new byte[keySize];
        byte[] valueBytes = new byte[valueSize];

        buffer.get(keyBytes);
        buffer.get(valueSize);

        return new Entry(
                timestamp,
                new String(keyBytes, StandardCharsets.UTF_8),
                new String(valueBytes, StandardCharsets.UTF_8)
        );
    }

    public Map<String, Entry>getAll() throws IOException {
        Map<String, Entry> entries = new HashMap<>();
        for(String key : keyDir.keySet())
            entries.put(key, get(key));

        return entries;
    }

    private byte[] serializeEntry(Entry entry) {
        // <timestamp><key-size><value-size><key><value>
        byte[] keyBytes = entry.getKey().getBytes(StandardCharsets.UTF_8);
        byte[] valueBytes = entry.getValue().getBytes(StandardCharsets.UTF_8);

        int totalSize =
                keyBytes.length +
                valueBytes.length +
                Long.BYTES +
                (Integer.BYTES * 2);

        ByteBuffer byteBuffer = ByteBuffer.allocate(totalSize);
        return byteBuffer
                .putLong(entry.getTimestamp())
                .putInt(keyBytes.length)
                .putInt(valueBytes.length)
                .put(keyBytes)
                .put(valueBytes)
                .array();
    }

    @Override
    public void close() throws IOException {
        segmentsManager.close();
    }
}
