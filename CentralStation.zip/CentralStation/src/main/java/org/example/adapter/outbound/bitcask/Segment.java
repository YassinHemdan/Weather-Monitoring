package org.example.adapter.outbound.bitcask;

import java.io.EOFException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class Segment {
    private enum State {
        ACTIVE,
        SEALED
    }

    private final String fileId;
    private final FileChannel fileChannel;

    private volatile State fileState = State.ACTIVE;

    public Segment(String fileId, Path path) throws IOException {
        this.fileId = fileId;

        fileChannel = FileChannel.open(
                path,
                StandardOpenOption.CREATE,
                StandardOpenOption.READ,
                StandardOpenOption.WRITE,
                StandardOpenOption.TRUNCATE_EXISTING
        );
    }

    public byte [] read(long offset, long length) throws IOException {
        if (offset < 0 || length < 0)
            throw new IllegalArgumentException("Offset and length must be non-negative");

        ByteBuffer buffer = ByteBuffer.allocate((int)length);
        while (buffer.hasRemaining()) {
            int bytesRead = fileChannel.read(buffer, offset);

            if (bytesRead == -1) {
                throw new EOFException("Not enough bytes in the file");
            }

            offset += bytesRead;
        }

        buffer.flip();

        byte[] bytes = new byte[buffer.remaining()];
        buffer.get(bytes);

        return bytes;
    }


    public long append(byte[] data) throws IOException, IllegalAccessException {
        if (this.fileState == State.SEALED)
            throw new IllegalAccessException("Can't write to a read-only file");

        long currentOffset = fileChannel.size();
        writeAt(data, fileChannel.size());

        return currentOffset;
    }

    private void writeAt(byte[] data, long offset) throws IOException {
        ByteBuffer buffer = ByteBuffer.wrap(data);

        long position = offset;
        while (buffer.hasRemaining()) {
            int written = fileChannel.write(buffer, position);

            if (written == 0) {
                Thread.onSpinWait();
                continue;
            }

            position += written;
        }
    }

    public String fileId() {
        return this.fileId;
    }
    public long size() throws IOException {
        return fileChannel.size();
    }
    public void seal() {
        this.fileState = State.SEALED;
    }
    public void close() throws IOException {
        fileChannel.close();
    }
}
