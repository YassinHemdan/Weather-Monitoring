package org.example.adapter.outbound.bitcask;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

public class SegmentsManager {

    private volatile Segment activeSegment;
    private final Map<String, Segment> sealedSegments = new ConcurrentHashMap<>();
    private AtomicLong lastId = new AtomicLong(1);

    private final Path dbDir;
    private final long MAX_FILE_SIZE = 1000_000_000; // to be changed to a small value for testing

    // TODO: if there exist files, we should read them and detect
    // TODO:   where is the active segment and where are the sealed/read-only ones
    // TODO: compaction and merge.

    public SegmentsManager(Path dbDir) throws IOException {
        this.dbDir = dbDir;
        this.activeSegment = createActiveSegment();
    }

    public byte[] read(long offset, String fileId, long length) throws IOException {
        Segment segmentToRead;
        if (fileId.equals(activeSegment.fileId()))
            segmentToRead = activeSegment;
        else
            segmentToRead = sealedSegments.get(fileId);

        if (segmentToRead == null) {
            throw new IllegalArgumentException("file: " + fileId + " does not exist");
        }

        return segmentToRead.read(offset, length);
    }

    public EntryLocation write(byte[] data) throws IOException, IllegalAccessException {
        if (this.activeSegment.size() + data.length > MAX_FILE_SIZE) {
            newActiveSegment();
        }

        long offset = this.activeSegment.append(data);

        return new EntryLocation(activeSegment.fileId(), offset, data.length);
    }

    private void newActiveSegment() throws IOException {
        this.activeSegment.seal();
        this.sealedSegments.put(this.activeSegment.fileId(), activeSegment);
        this.activeSegment = createActiveSegment();
    }

    private Segment createActiveSegment() throws IOException {
        String id = timestamp();
        Path segmentPath = dbDir.resolve(id + ".data");

        return new Segment(id, segmentPath);
    }
    private synchronized String timestamp() {
        long now = System.currentTimeMillis();
        lastId.set(Math.max(now, lastId.get() + 1));

        return Long.toString(lastId.get());
    }

    public void close() throws IOException {
        activeSegment.close();
        for (Segment segment : sealedSegments.values()){
            segment.close();
        }
    }
}
