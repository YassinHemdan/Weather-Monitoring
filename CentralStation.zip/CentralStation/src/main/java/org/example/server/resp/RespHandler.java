package org.example.server.resp;

import org.example.server.TcpServer;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class RespHandler implements TcpServer.ConnectionHandler {
    @Override
    public void handle(Socket socket) throws IOException {
        // TODO
    }
}
