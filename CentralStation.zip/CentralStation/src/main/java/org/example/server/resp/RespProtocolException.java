package org.example.server.resp;

public class RespProtocolException extends RuntimeException {
    public RespProtocolException(String message) {
        super(message);
    }
}
